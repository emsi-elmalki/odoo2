## Module <product_barcode>

#### 10.08.2020
#### Version 14.0.1.0.0
##### ADD
- Initial Commit
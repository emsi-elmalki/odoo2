**Changelog**
------------------------------

**14.0.1.0.3** 2021-12-18

- Add barcode types in the 57x35 label template

- Add currency symbol position before/after in the 57x35 label template

- Add option Humanreadable barcode to the wizard

**14.0.1.0.2** 2021-05-31

- Fix save_eval error: NameError: name Product_labels_57x35mm is not defined

**14.0.1.0.1** 2021-03-28

- change print_report_name (spaces removed)

**14.0.1.0.0** 2021-02-18

- Migrate to 14.0


